export interface MyItems{
    vegetableid:number,
    vegetablename:string,
    vegetablecost:string,
    vegetableimg:string,
    vo:number,
    vid:number
}