import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdfruitsComponent } from './adfruits.component';

describe('AdfruitsComponent', () => {
  let component: AdfruitsComponent;
  let fixture: ComponentFixture<AdfruitsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdfruitsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdfruitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
