import { Component, OnInit } from '@angular/core';
import{NgForm} from '@angular/forms';
import { itemsservice } from '../items/items.service';
import { Register } from './register';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit{
  constructor(
    public kitchenserv:itemsservice
  )
  {
  }
  ngOnInit(): void {
  }

  register = new Register();
  save(registerForm: NgForm){
    console.log(JSON.stringify(registerForm.value));
  }
  sub()
  {
    alert("Registered Successfully");
    alert("To validate your account.Login here");
  }

}
