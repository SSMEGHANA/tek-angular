import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AdComponent } from './ad/ad.component';
import { AdcComponent } from './adc/adc.component';
import { AddComponent } from './add/add.component';
import { Add1Component } from './add1/add1.component';
import { AdfruitsComponent } from './adfruits/adfruits.component';
import { AdvegComponent } from './adveg/adveg.component';
import { CartComponent } from './cart/cart.component';
import { ContactComponent } from './contact/contact.component';
import { FruitsComponent } from './fruits/fruits.component';
import { Fruits1Component } from './fruits1/fruits1.component';
import { HomeComponent } from './home/home.component';
import { ItemsComponent } from './items/items.component';
import { Items1Component } from './items1/items1.component';
import { LoginComponent } from './login/login.component';
import { OrderComponent } from './order/order.component';
import { PayComponent } from './pay/pay.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'items',component:ItemsComponent},
  {path:'fruits',component:FruitsComponent},
  {path:'register',component:RegisterComponent},
  {path:'about',component:AboutComponent},
  {path:'adveg',component:AdvegComponent},
  {path:'ad',component:AdComponent},
  {path:'adfruits',component:AdfruitsComponent},
  {path:'cart',component:CartComponent},
  {path:'login',component:LoginComponent},
  {path:'order',component:OrderComponent},
  {path:'contact',component:ContactComponent},
  {path:'adc',component:AdcComponent},
  {path:'add',component:AddComponent},
  {path:'add1',component:Add1Component},
  {path:'pay',component:PayComponent},
  {path:'items1',component:Items1Component},
  {path:'fruits1',component:Fruits1Component},
  {path:'',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
