import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { MyItems } from '../items/items';
import { itemsservice } from '../items/items.service';
import { Kitchens } from "./add";

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})

export class AddComponent implements OnInit {
  vegetableid:number;
  vegetablename:string;
  vegetablecost:string;
  vegetableimg:string;
  vo:number;
  vid:number;
    kitchens:MyItems[]=[];

    kitchen=new Kitchens();
  constructor(private fruitservice:itemsservice, private route:Router) { }

  ngOnInit(): void {
    this.kitchens=this.fruitservice.getItems();
  }
  save(userForm:NgForm){
    alert("Form Submitted"+this.kitchen.vegetableimg);
  }
  onFruitAdd(userForm:NgForm){
    let a={
      vegetableid:+this.kitchen.vegetableid,
      vegetablename:this.kitchen.vegetablename,
      vegetablecost:this.kitchen.vegetablecost,
      vegetableimg:this.kitchen.vegetableimg,
      vo:+this.kitchen.vo,
      vid:+this.kitchen.vid

    }
    this.kitchens.push(a);
    alert("Item Added");
    this.route.navigate(['./adveg']);    
  }

}