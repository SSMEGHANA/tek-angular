import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Admin } from './adc';
@Component({
  selector: 'app-adc',
  templateUrl: './adc.component.html',
  styleUrls: ['./adc.component.css']
})
export class AdcComponent implements OnInit {

  new_pass:string;
  r_new_pass:string;
    constructor(private route:Router) { }
  
    ngOnInit(): void {
    }
    admin=new Admin();
    Pass_change(userForm:NgForm){
  
      if(this.admin.password=='nagadurga@23')
      {
        if(this.new_pass==this.r_new_pass)
        {
          alert("Admin password changed");
          this.route.navigate(['./ad']);
        }
        else{
          alert("Re-enter password correctly");
        }
      }
  
      else{
        alert("Enter valid current password");
      }
    }
}
