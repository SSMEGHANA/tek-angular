export interface MyFruits{
    vegetableid:number,
    vegetablename:string,
    vegetablecost:string,
    vegetableimg:string,
    vo:number,
    vid:number
}