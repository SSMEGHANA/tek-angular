import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { ItemsComponent } from './items/items.component';
import { FruitsComponent } from './fruits/fruits.component';
import { FormsModule } from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { AdvegComponent } from './adveg/adveg.component';
import { AdComponent } from './ad/ad.component';
import { AdfruitsComponent } from './adfruits/adfruits.component';
import { CartComponent } from './cart/cart.component';
import { OrderComponent } from './order/order.component';
import { AddComponent } from './add/add.component';
import { AdcComponent } from './adc/adc.component';
import { Add1Component } from './add1/add1.component';
import { PayComponent } from './pay/pay.component';
import { Items1Component } from './items1/items1.component';
import { Fruits1Component } from './fruits1/fruits1.component';
@NgModule({
  declarations: [
    AppComponent,
    ContactComponent,
    HomeComponent,
    ItemsComponent,
    FruitsComponent,
    RegisterComponent,
    AboutComponent,
    LoginComponent,
    AdvegComponent,
    AdComponent,
    AdfruitsComponent,
    CartComponent,
    OrderComponent,
    AddComponent,
    AdcComponent,
    Add1Component,
    PayComponent,
    Items1Component,
    Fruits1Component,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
