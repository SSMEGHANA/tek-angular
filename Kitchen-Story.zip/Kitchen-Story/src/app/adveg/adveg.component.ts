import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import { MyItems } from '../items/items';
import { itemsservice } from '../items/items.service';
@Component({
  selector: 'app-adveg',
  templateUrl: './adveg.component.html',
  styleUrls: ['./adveg.component.css']
})
export class AdvegComponent implements OnInit {

  imgWidth="100";
  imgHeight="100";
  imgRadius="20";
  vtbl:MyItems[]=[];
  name:MyItems;
  constructor(private route:Router,private aroute:ActivatedRoute,private utservice:itemsservice){}

  ngOnInit(): void {
    this.vtbl=this.utservice.getItems();
    
      }
      deleteItem(name:string)
      {
        const index=this.vtbl.findIndex(
          item=>item.vegetablename===name
        )
        if(index>=0){
          this.vtbl.splice(index,1);
        }
      }
    
    onDelete(name:string)
    {
      if(window.confirm("Are you sure,want to delete this item?"))
      {
        this.deleteItem(name);
        this.route.navigate(['/adfruit']);
      }
    }
    addItem(id:number)
    {
      this.vtbl.push(this.vtbl[id-1]);
    }
    onadd(id:number)
    {
      this.addItem(id);
      this.route.navigate(['/adfruit']);
    }

}


